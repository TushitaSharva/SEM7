PROGRAMMING ASSIGNMENT 1 : MEASURING MATRIX SPARSITY
JANGA TUSHITA SHARVA
CS21BTECH11022
-------------------------------------------------------
This directory consists of the following files:
 - Assgn1-Chunk-CS21BTECH11022.cpp
 - Assgn1-Mixed-CS21BTECH11022.cpp
 - Assgn1-Dynmaic-CS21BTECH11022.cpp
 - Assgn1-ExtraCredit-CS21BTECH11022.cpp
 - Assgn1-Report-CS21BTECH11022.cpp
 - Assgn1-ReadMe-CS21BTECH11022.cpp
 - inp.txt
 - run.sh
-----------------------------------------------------------------
'inp.txt' is a sample input file. The file contains
the following information, as mentioned in the problem statement. 
The first line contains four numbers (seperated by space)
 - N: Number of rows in matrix
 - S: Sparsity of the matrix
 - K: Number of threads
 - rowInc: For Dynamic Approach
 Following N lines have the input matrix for which we have to calculate sparsity for.


NOTE:
- There must be inp.txt which aligns with above conditions. I have kept an inp.txt in this folder which can be modified.
- There must be a folder `outputs`. I have submitted this too, along with some sample output files inside the folder.
- After programs are executed, the outputs will be in the outputs folder, so as to prevent any confusion
- Everytime the programs are executed, the files in the outputs folder are deleted by the script itself if there are any.
-----------------------------------------------------------------
This directory contains a bash script "run.sh". To run this
file,
Change the permissions of the executable 
 - chmod u+x run.sh
Run the script
 - ./run.sh
It will delete all the previous output files and execute all the programs at once
-----------------------------------------------------------------
To execute only one file at a time, you may comment out any of those lines or follow these setps:
- For chunk:
    $ g++ -std=c++14 Assgn1-Chunk-CS21BTECH11022.cpp -pthread && ./a.out
- For mixed:
    $ g++ -std=c++14 Assgn1-Mixed-CS21BTECH11022.cpp -pthread && ./a.out
- For dynamic:
    $ g++ -std=c++14 Assgn1-Dynamic-CS21BTECH11022.cpp -pthread && ./a.out
- For extra credit:
    $ g++ -std=c++14 Assgn1-ExtraCredit-CS21BTECH11022.cpp -pthread && ./a.out

REMEBER TO DELETE THE OUTPUT FILES IF YOU ARE NOT RUNNING THE SCRIPT. ELSE THE PREVIOUS FILES GET APPENDED.